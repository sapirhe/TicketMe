<main>
    <div class="container">
    <div class="description ">
        <h1>הרכישה בוצעה בהצלחה</h1><br>
        <div class="center" id="purchMsg"><a href="<?php echo site_url(); ?>/Shows_controller/HomePage" id="submit" class="link" type="button">מעבר לדף הבית</a></div>
    </div>
    </div>
</main>
